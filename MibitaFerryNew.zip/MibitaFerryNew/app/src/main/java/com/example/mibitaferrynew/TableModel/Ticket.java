package com.example.mibitaferrynew.TableModel;

import android.graphics.ColorSpace;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

@Table(name = "ticket")

public class Ticket extends Model {
    @Column(name = "remote_id", unique = true)
    public int remote_id;

    @Column(name = "Ticket_type")
    public String ticket_type;

    @Column(name = "date")
    public String date;

    @Column(name = "cost")
    public int  cost;

    @Column(name = "reference")
    public String ref_no;

    public Ticket() {
        super();
    }


}
