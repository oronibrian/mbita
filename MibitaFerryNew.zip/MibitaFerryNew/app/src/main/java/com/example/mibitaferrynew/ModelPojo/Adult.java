package com.example.mibitaferrynew.ModelPojo;

public class Adult {
    String title;
    String ref;
    int price;

    public Adult(String title, String ref, int price) {
        this.title = title;
        this.ref = ref;
        this.price = price;
    }
}
